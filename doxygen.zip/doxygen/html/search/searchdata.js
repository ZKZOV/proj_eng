var indexSectionsWithContent =
{
  0: "abcdhimprst",
  1: "c",
  2: "m",
  3: "chmpst",
  4: "abcdimr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis"
};

