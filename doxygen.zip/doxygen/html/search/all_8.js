var searchData=
[
  ['real_16',['real',['../structcomplexo.html#a03b73fa1cd3a656bf6829ebb68049b29',1,'complexo']]]
];
