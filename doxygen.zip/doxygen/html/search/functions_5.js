var searchData=
[
  ['teste_5fcalc_5fsvd_40',['teste_calc_svd',['../matrizes_8h.html#a1b347feb2979a0b6a31f14dd34202f61',1,'teste_calc_svd():&#160;matrizes.c'],['../matrizes_8c.html#a1b347feb2979a0b6a31f14dd34202f61',1,'teste_calc_svd():&#160;matrizes.c']]],
  ['teste_5fconjugada_41',['teste_conjugada',['../matrizes_8c.html#a3f34083b0750b199541170c8a0b71476',1,'teste_conjugada():&#160;matrizes.c'],['../matrizes_8h.html#a3f34083b0750b199541170c8a0b71476',1,'teste_conjugada():&#160;matrizes.c']]],
  ['teste_5fhermitiana_42',['teste_hermitiana',['../matrizes_8c.html#a1e5a53c3ce5b6b00a762f65dc278f2ac',1,'teste_hermitiana():&#160;matrizes.c'],['../matrizes_8h.html#a1e5a53c3ce5b6b00a762f65dc278f2ac',1,'teste_hermitiana():&#160;matrizes.c']]],
  ['teste_5fprodutoescalar_43',['teste_produtoEscalar',['../matrizes_8c.html#a351fa790e4176b1e5139e06f31e4a39d',1,'teste_produtoEscalar():&#160;matrizes.c'],['../matrizes_8h.html#a351fa790e4176b1e5139e06f31e4a39d',1,'teste_produtoEscalar():&#160;matrizes.c']]],
  ['teste_5fprodutomatricial_44',['teste_produtoMatricial',['../matrizes_8h.html#a62bc2ed53cbd9264c5c9d3dd5eacabb7',1,'teste_produtoMatricial():&#160;matrizes.c'],['../matrizes_8c.html#a62bc2ed53cbd9264c5c9d3dd5eacabb7',1,'teste_produtoMatricial():&#160;matrizes.c']]],
  ['teste_5fsoma_45',['teste_soma',['../matrizes_8c.html#acc0987475f11220eb43a14073099ee98',1,'teste_soma():&#160;matrizes.c'],['../matrizes_8h.html#acc0987475f11220eb43a14073099ee98',1,'teste_soma():&#160;matrizes.c']]],
  ['teste_5fsubtracao_46',['teste_subtracao',['../matrizes_8c.html#a79117c2187097d1960d8fb0bc3135dda',1,'teste_subtracao():&#160;matrizes.c'],['../matrizes_8h.html#a79117c2187097d1960d8fb0bc3135dda',1,'teste_subtracao():&#160;matrizes.c']]],
  ['teste_5ftransposta_47',['teste_transposta',['../matrizes_8c.html#a13393f243e583fb11725f563de8436fb',1,'teste_transposta():&#160;matrizes.c'],['../matrizes_8h.html#a13393f243e583fb11725f563de8436fb',1,'teste_transposta():&#160;matrizes.c']]],
  ['transposta_48',['transposta',['../matrizes_8c.html#aa8b22d31800c4793a34350900ca14fe6',1,'transposta(complexo a[3][3], complexo mxt[3][3]):&#160;matrizes.c'],['../matrizes_8h.html#aa8b22d31800c4793a34350900ca14fe6',1,'transposta(complexo a[3][3], complexo mxt[3][3]):&#160;matrizes.c']]]
];
