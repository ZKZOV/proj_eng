var searchData=
[
  ['soma_38',['soma',['../matrizes_8c.html#a8de4a9f7840a27bc159c00a6e3e72f4b',1,'soma(complexo a[3][3], complexo b[3][3], complexo mxt[3][3]):&#160;matrizes.c'],['../matrizes_8h.html#a8de4a9f7840a27bc159c00a6e3e72f4b',1,'soma(complexo a[3][3], complexo b[3][3], complexo mxt[3][3]):&#160;matrizes.c']]],
  ['subtracao_39',['subtracao',['../matrizes_8c.html#a463374c04a58c9f5f5ef3e63ab6ab58d',1,'subtracao(complexo a[3][3], complexo b[3][3], complexo mxt[3][3]):&#160;matrizes.c'],['../matrizes_8h.html#a463374c04a58c9f5f5ef3e63ab6ab58d',1,'subtracao(complexo a[3][3], complexo b[3][3], complexo mxt[3][3]):&#160;matrizes.c']]]
];
