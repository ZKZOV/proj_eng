var searchData=
[
  ['b_50',['b',['../matrizes_8c.html#ad6b69a4c1d4eca6c23e77c6f11e83320',1,'matrizes.c']]]
];
