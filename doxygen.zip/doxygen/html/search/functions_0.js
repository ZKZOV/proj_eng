var searchData=
[
  ['conjugada_32',['conjugada',['../matrizes_8c.html#aae61893b8a7d5856da680a64b2837ba1',1,'conjugada(complexo a[3][3], complexo mxt[3][3]):&#160;matrizes.c'],['../matrizes_8h.html#aae61893b8a7d5856da680a64b2837ba1',1,'conjugada(complexo a[3][3], complexo mxt[3][3]):&#160;matrizes.c']]]
];
