var searchData=
[
  ['print_5fname_13',['print_name',['../matrizes_8c.html#a7981a626703ff2312463e3a17a26661e',1,'print_name():&#160;matrizes.c'],['../matrizes_8h.html#a7981a626703ff2312463e3a17a26661e',1,'print_name():&#160;matrizes.c']]],
  ['produto_5fescalar_14',['produto_escalar',['../matrizes_8c.html#ac5045a2f094b9acd022a0d24ac5ffc56',1,'produto_escalar(complexo a[3][3], complexo b[3][3], complexo mxt[3][3]):&#160;matrizes.c'],['../matrizes_8h.html#ac5045a2f094b9acd022a0d24ac5ffc56',1,'produto_escalar(complexo a[3][3], complexo b[3][3], complexo mxt[3][3]):&#160;matrizes.c']]],
  ['produto_5fmatricial_15',['produto_matricial',['../matrizes_8c.html#a0f064876a3a10cf7e1590225770222ac',1,'produto_matricial(complexo a[3][3], complexo b[3][3], complexo mxt[3][3]):&#160;matrizes.c'],['../matrizes_8h.html#a0f064876a3a10cf7e1590225770222ac',1,'produto_matricial(complexo a[3][3], complexo b[3][3], complexo mxt[3][3]):&#160;matrizes.c']]]
];
