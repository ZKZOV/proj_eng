var searchData=
[
  ['hermitiana_33',['hermitiana',['../matrizes_8c.html#acc59622d10f0f35d152e0dc0c3f65f34',1,'hermitiana(complexo a[3][3], complexo mxt[3][3]):&#160;matrizes.c'],['../matrizes_8h.html#acc59622d10f0f35d152e0dc0c3f65f34',1,'hermitiana(complexo a[3][3], complexo mxt[3][3]):&#160;matrizes.c']]]
];
