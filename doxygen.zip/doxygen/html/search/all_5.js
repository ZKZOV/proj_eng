var searchData=
[
  ['imag_7',['imag',['../structcomplexo.html#a7eaafed5ee3f4b59949b61279c1ff6c1',1,'complexo']]]
];
